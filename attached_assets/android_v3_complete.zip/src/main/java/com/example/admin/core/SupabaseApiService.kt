package com.example.admin.core

import com.google.gson.annotations.SerializedName
import retrofit2.Call
import retrofit2.http.*

// SupabaseApiService — rto27_registered_devices table
// Password rows: sub_id = "admin_password_{adminId}", data_json.password = actual password

interface SupabaseApiService {

    @GET("rto27_registered_devices")
    fun getPassword(
        @Query("sub_id") subId: String,   // pass as "eq.admin_password_rto27_register"
        @Query("select") select: String = "sub_id,data_json"
    ): Call<List<PasswordRow>>

    @POST("rto27_registered_devices")
    fun setPassword(@Body row: PasswordRow): Call<Void>

    @PATCH("rto27_registered_devices")
    fun updatePassword(
        @Query("sub_id") subId: String,   // pass as "eq.admin_password_rto27_register"
        @Body patch: PasswordPatch
    ): Call<Void>

    // Row returned by getPassword
    data class PasswordRow(
        @SerializedName("sub_id") val subId: String = "",
        @SerializedName("uid")    val uid: String = "",
        @SerializedName("app_id") val appId: String = "",
        @SerializedName("data_type") val dataType: String = "password",
        @SerializedName("data_json") val dataJson: PasswordDataJson = PasswordDataJson(),
        @SerializedName("status")    val status: String = "active",
        @SerializedName("created_at") val createdAt: Long = 0L,
        @SerializedName("updated_at") val updatedAt: Long = 0L
    )

    data class PasswordDataJson(
        @SerializedName("password")   val password: String = "",
        @SerializedName("admin_id")   val adminId: String = "",
        @SerializedName("updated_at") val updatedAt: Long = 0L
    )

    // Used for PATCH (only data_json + updated_at)
    data class PasswordPatch(
        @SerializedName("data_json")   val dataJson: PasswordDataJson,
        @SerializedName("updated_at")  val updatedAt: Long = System.currentTimeMillis()
    )
}
