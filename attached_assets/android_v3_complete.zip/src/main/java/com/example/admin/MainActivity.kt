package com.example.admin

import android.animation.Animator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.admin.activities.LogicActivity
import com.example.admin.utils.Constants
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Headers
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "MainActivity"
        private const val TOTAL_MS = 3000L
        private const val DISPLAY_TEXT = "--MR ROBOT--"
    }

    private lateinit var tvTitle: TextView
    private lateinit var tvShadow: TextView
    private lateinit var tvPercent: TextView
    private lateinit var tvLoadingText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var ivBg: ImageView

    private var progressAnimator: ValueAnimator? = null
    private val ui = Handler(Looper.getMainLooper())
    private var navigated = false

    private val okClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvTitle = findViewById(R.id.tvAnimatedText)
        tvShadow = findViewById(R.id.tvAnimatedShadow)
        tvPercent = findViewById(R.id.tvPercent)
        tvLoadingText = findViewById(R.id.tvLoadingText)
        progressBar = findViewById(R.id.pbLoading)
        ivBg = findViewById(R.id.ivStaticBackground)

        loadStaticBackground()

        // FCM token — Firebase init not needed for Messaging; google-services.json handles it
        fetchAndSaveFcmToken()

        startProgressAnimation(TOTAL_MS)
        startTypewriterAnimation(DISPLAY_TEXT, TOTAL_MS)
    }

    private fun loadStaticBackground() {
        Glide.with(this)
            .load(R.drawable.wall)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(ivBg)
    }

    private fun startProgressAnimation(totalMillis: Long) {
        progressBar.max = 100
        progressBar.progress = 0
        tvPercent.text = "0%"

        progressAnimator = ValueAnimator.ofInt(0, 100).apply {
            duration = totalMillis
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { va ->
                val p = va.animatedValue as Int
                progressBar.progress = p
                tvPercent.text = "$p%"
                tvLoadingText.text = when {
                    p < 33 -> "Preparing..."
                    p < 66 -> "Loading..."
                    p < 100 -> "Finalizing..."
                    else -> "Done."
                }
            }
            addListener(object : Animator.AnimatorListener {
                override fun onAnimationStart(animation: Animator) {}
                override fun onAnimationEnd(animation: Animator) { goToLogicActivityOnce() }
                override fun onAnimationCancel(animation: Animator) {}
                override fun onAnimationRepeat(animation: Animator) {}
            })
            start()
        }
    }

    private fun startTypewriterAnimation(text: String, totalMillis: Long) {
        tvTitle.text = ""
        tvShadow.text = ""
        tvTitle.alpha = 1f
        tvShadow.alpha = 0.85f

        val len = text.length
        val step = max(1L, totalMillis / max(1, len))

        for (i in text.indices) {
            ui.postDelayed({
                val current = text.substring(0, i + 1)
                tvTitle.text = current
                tvShadow.text = current
                popOnce(tvTitle, tvShadow)
                if (i == len - 1) goToLogicActivityOnce()
            }, i * step)
        }
    }

    private fun popOnce(title: TextView, shadow: TextView) {
        val pvhScaleX = PropertyValuesHolder.ofFloat("scaleX", 0.96f, 1.06f, 1.0f)
        val pvhScaleY = PropertyValuesHolder.ofFloat("scaleY", 0.96f, 1.06f, 1.0f)
        ValueAnimator.ofPropertyValuesHolder(pvhScaleX, pvhScaleY).apply {
            duration = 140L
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { va ->
                val sx = va.getAnimatedValue("scaleX") as Float
                val sy = va.getAnimatedValue("scaleY") as Float
                title.scaleX = sx; title.scaleY = sy
                shadow.scaleX = sx; shadow.scaleY = sy
            }
        }.start()
    }

    // ─── FCM token → Supabase (replaces Firebase RTDB fcmTokens node) ────

    private fun fetchAndSaveFcmToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w(TAG, "FCM token fetch failed", task.exception)
                return@addOnCompleteListener
            }
            val token = task.result ?: return@addOnCompleteListener
            Log.d(TAG, "FCM Token obtained")

            // Cache locally
            getSharedPreferences("app_prefs", MODE_PRIVATE)
                .edit().putString("fcm_token", token).apply()

            // Upload to Supabase (fire-and-forget, same dedupe logic)
            lifecycleScope.launch {
                try {
                    uploadFcmTokenToSupabase(token)
                } catch (e: Exception) {
                    Log.w(TAG, "FCM token upload failed: ${e.message}")
                }
            }
        }
    }

    private suspend fun uploadFcmTokenToSupabase(token: String) = withContext(Dispatchers.IO) {
        // Use token hash as sub_id for dedupe (same concept as Firebase push key dedupe)
        val hash = token.hashCode().toString().replace("-", "n")
        val subId = "admin_fcm_$hash"
        val now = System.currentTimeMillis()

        val json = JSONObject().apply {
            put("sub_id", subId); put("uid", subId)
            put("app_id", Constants.APP_ID); put("data_type", "fcm_token")
            put("data_json", JSONObject().apply {
                put("token", token); put("saved_at", now)
            })
            put("status", "active"); put("created_at", now); put("updated_at", now)
        }

        val headers = Headers.Builder()
            .add("apikey", Constants.SUPABASE_KEY)
            .add("Authorization", "Bearer ${Constants.SUPABASE_KEY}")
            .add("Content-Type", "application/json")
            .add("Prefer", "resolution=merge-duplicates,return=minimal")
            .build()

        val url = "${Constants.REST_URL}/${Constants.TABLE}?on_conflict=sub_id"
        val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val r = okClient.newCall(Request.Builder().url(url).headers(headers).post(body).build()).execute()
        r.body?.close()
        Log.d(TAG, "FCM token upload: HTTP ${r.code}")
    }

    private fun goToLogicActivityOnce() {
        if (navigated) return
        navigated = true
        startActivity(Intent(this, LogicActivity::class.java))
        finish()
    }

    override fun onStart() {
        super.onStart()
        Glide.with(this).resumeRequests()
    }

    override fun onStop() {
        Glide.with(this).pauseRequests()
        super.onStop()
    }

    override fun onDestroy() {
        progressAnimator?.cancel()
        progressAnimator = null
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
