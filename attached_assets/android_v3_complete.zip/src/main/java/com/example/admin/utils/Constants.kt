package com.example.admin.utils

object Constants {
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // EK HI SUPABASE PROJECT — sabhi data yahan se aata hai
    //
    // SUPABASE_KEY ki jagah apni real anon/public key daalo:
    //   Supabase Dashboard → project → Settings → API → anon/public
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    const val PROJECT_REF  = "imfwqoocwfvvtjghgofi"
    const val SUPABASE_URL = "https://$PROJECT_REF.supabase.co"
    const val REST_URL     = "$SUPABASE_URL/rest/v1"
    const val SUPABASE_KEY = "YOUR_SUPABASE_ANON_KEY"   // ← yahan real key daalo

    const val TABLE = "rto27_registered_devices"
    const val APP_ID = "rto27"
}
