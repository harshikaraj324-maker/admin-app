package com.example.admin.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.admin.R
import com.example.admin.network.SupabaseApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

class DataFetchService : Service() {

    companion object {
        private const val TAG = "DataFetchService"
        private const val NOTIF_ID = 12001
        private const val CHANNEL_ID = "data_fetch_service_channel"
        private const val OVERVIEW_TICK_MS = 5_000L   // same as original
        private const val POLL_INTERVAL_MS = 30_000L  // Supabase poll every 30s
    }

    private val supabaseApi = SupabaseApi()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val destroyed = AtomicBoolean(false)

    // In-memory state — same structure as original
    private val registeredDevices = CopyOnWriteArrayList<String>()
    private val statusMap = ConcurrentHashMap<String, Boolean>()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannelIfNeeded()
        startForeground(NOTIF_ID, buildNotification("Monitoring device status"))
        Log.d(TAG, "Service created and foreground started")

        startPolling()
        startOverviewLogger()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        destroyed.set(true)
        scope.cancel()
        stopForeground(true)
        Log.d(TAG, "Service destroyed")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ─── Polling (replaces Firebase ChildEventListener on registeredDevices + status) ──

    private fun startPolling() {
        scope.launch {
            while (isActive && !destroyed.get()) {
                try {
                    refreshFromSupabase()
                } catch (t: Throwable) {
                    Log.e(TAG, "Poll error", t)
                }
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    private suspend fun refreshFromSupabase() {
        // Fetch registered devices (replaces dbRefData "registeredDevices")
        supabaseApi.getAllDevices().onSuccess { devices ->
            registeredDevices.clear()
            devices.forEach { registeredDevices.add(it.uid) }
            Log.d(TAG, "registeredDevices updated size=${registeredDevices.size}")
        }.onFailure { e ->
            Log.w(TAG, "getAllDevices failed: ${e.message}")
        }

        // Fetch statuses (replaces dbRefStatus "status" / "deviceStatusUpdates")
        supabaseApi.getLatestDeviceStatuses().onSuccess { statusesMap ->
            statusMap.clear()
            statusesMap.forEach { (uid, status) ->
                statusMap[uid] = status.online
                Log.d(TAG, "STATUS updated: $uid -> ${status.online}")
            }
        }.onFailure { e ->
            Log.w(TAG, "getLatestDeviceStatuses failed: ${e.message}")
        }
    }

    // ─── Overview logger (same as original — every 5s) ───────────────

    private fun startOverviewLogger() {
        scope.launch {
            while (isActive && !destroyed.get()) {
                delay(OVERVIEW_TICK_MS)
                try { logOverview() } catch (t: Throwable) { Log.e(TAG, "Overview tick error", t) }
            }
        }
    }

    private fun logOverview() {
        val online = statusMap.filter { it.value }.keys.toList()
        val offline = statusMap.filter { !it.value }.keys.toList()
        Log.d(TAG, "=== OVERVIEW ===")
        Log.d(TAG, "Registered devices: ${registeredDevices.size}")
        Log.d(TAG, "Online devices(${online.size}): $online")
        Log.d(TAG, "Offline devices(${offline.size}): $offline")
        Log.d(TAG, "================")
    }

    // ─── Notification ────────────────────────────────────────────────

    private fun createNotificationChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val nm = getSystemService(NotificationManager::class.java)
                val ch = NotificationChannel(CHANNEL_ID, "Data Fetch Service", NotificationManager.IMPORTANCE_LOW)
                ch.description = "Monitors device status"
                nm.createNotificationChannel(ch)
            } catch (e: Exception) {
                Log.w(TAG, "createNotificationChannel error: ${e.message}")
            }
        }
    }

    private fun buildNotification(text: String = "Device monitor running"): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Device Monitor")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher)
            .setOngoing(true)
            .build()
}
