package com.example.admin.activities

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.admin.R
import com.example.admin.core.*
import com.example.admin.network.SupabaseApi
import com.example.admin.utils.Constants
import com.google.android.material.progressindicator.CircularProgressIndicator
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.textview.MaterialTextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Headers
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class LogicActivity : AppCompatActivity() {

    private val ADMIN_ID = "rto27_register"
    private val DEV_PHONE = "639511497898"

    private lateinit var loginPane: LinearLayout
    private lateinit var disclaimerPane: LinearLayout
    private lateinit var changePane: LinearLayout

    private lateinit var etAdminId: EditText
    private lateinit var tilPassword: TextInputLayout
    private lateinit var etPassword: EditText
    private lateinit var btnLoginTv: MaterialTextView
    private lateinit var btnSkipTv: MaterialTextView
    private lateinit var btnChangeFromDisclaimerTv: MaterialTextView
    private lateinit var btnContactDeveloper: MaterialTextView
    private lateinit var btnLogoutAll: MaterialTextView
    private lateinit var tilNewPassword: TextInputLayout
    private lateinit var etNewPassword: EditText
    private lateinit var tilConfirmPassword: TextInputLayout
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnSaveTv: MaterialTextView
    private lateinit var btnCancelTv: MaterialTextView
    private lateinit var progress: CircularProgressIndicator

    private var currentWhatsAppNumber: String = DEV_PHONE
    private lateinit var deviceId: String
    private val expiry = ExpiryManager()
    @Volatile private var expiryNotified = false

    // Polling handlers (replaces Firebase realtime listeners)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var logoutPollRunnable: Runnable? = null
    private var sessionPollRunnable: Runnable? = null

    private val okClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    // ─── Lifecycle ────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_logic)

        deviceId = SessionManager.getDeviceId(this)
        bindViews()
        wireClicks()
        etAdminId.setText(ADMIN_ID)

        setupExpiryManager()
        fetchControlNumber()

        if (SessionManager.isLoggedIn(this)) {
            verifySession()
        } else {
            showPane(Pane.LOGIN)
        }
    }

    override fun onStart() {
        super.onStart()
        startLogoutPoll()
        if (SessionManager.isLoggedIn(this)) {
            startSessionMonitorPoll()
        }
    }

    override fun onStop() {
        super.onStop()
        stopLogoutPoll()
        stopSessionMonitorPoll()
    }

    override fun onDestroy() {
        super.onDestroy()
        expiry.stopRuntimeGuards()
    }

    // ─── Views ────────────────────────────────────────────────────

    private fun bindViews() {
        loginPane = findViewById(R.id.loginPane)
        disclaimerPane = findViewById(R.id.disclaimerPane)
        changePane = findViewById(R.id.changePane)
        etAdminId = findViewById(R.id.etAdminId)
        tilPassword = findViewById(R.id.tilPassword)
        etPassword = findViewById(R.id.etPassword)
        btnLoginTv = findViewById(R.id.btnLoginTv)
        btnSkipTv = findViewById(R.id.btnSkipTv)
        btnChangeFromDisclaimerTv = findViewById(R.id.btnChangeFromDisclaimerTv)
        btnContactDeveloper = findViewById(R.id.btnContactDeveloper)
        btnLogoutAll = findViewById(R.id.btnLogoutAll)
        tilNewPassword = findViewById(R.id.tilNewPassword)
        etNewPassword = findViewById(R.id.etNewPassword)
        tilConfirmPassword = findViewById(R.id.tilConfirmPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnSaveTv = findViewById(R.id.btnSaveTv)
        btnCancelTv = findViewById(R.id.btnCancelTv)
        progress = findViewById(R.id.progress)
    }

    private fun wireClicks() {
        btnLoginTv.setOnClickListener { performLogin() }
        btnSkipTv.setOnClickListener {
            startActivity(Intent(this, DeviceActivity::class.java))
            finish()
        }
        btnChangeFromDisclaimerTv.setOnClickListener { showPane(Pane.CHANGE) }
        btnContactDeveloper.setOnClickListener { openWhatsApp("Hello developer.") }
        btnLogoutAll.setOnClickListener { showLogoutAllConfirmation() }
        btnSaveTv.setOnClickListener { updatePassword() }
        btnCancelTv.setOnClickListener {
            clearChangeErrors()
            showPane(Pane.DISCLAIMER)
        }
    }

    // ─── Expiry (same logic, now uses Supabase inside ExpiryManager) ──

    private fun setupExpiryManager() {
        expiry.ensureWindow30DaysIfMissing(onDone = {
            expiry.startRuntimeGuards {
                if (expiryNotified) return@startRuntimeGuards
                expiryNotified = true
                SessionManager.setLoggedIn(this, false)
                runOnUiThread {
                    setLoading(false)
                    etPassword.text?.clear()
                    tilPassword.error = null
                    toast("Access expired. Please login again.")
                    showPane(Pane.LOGIN)
                }
                expiry.stopRuntimeGuards()
            }
        })
    }

    // ─── WhatsApp control number — now from Supabase admin_config_main ──

    private fun fetchControlNumber() {
        lifecycleScope.launch {
            try {
                SupabaseApi().getAdminConfig().onSuccess { cfg ->
                    if (cfg.status.equals("ON", ignoreCase = true) && cfg.number.isNotBlank()) {
                        currentWhatsAppNumber = cfg.number
                    } else {
                        currentWhatsAppNumber = DEV_PHONE
                    }
                }
            } catch (e: Exception) {
                currentWhatsAppNumber = DEV_PHONE
                Log.w("LogicActivity", "fetchControlNumber: ${e.message}")
            }
        }
    }

    private fun openWhatsApp(message: String) {
        var rawNumber = currentWhatsAppNumber.trim()
        if (!rawNumber.startsWith("+")) rawNumber = "+$rawNumber"
        val cleanNumber = rawNumber.replace(" ", "").replace("-", "")
        val url = "https://wa.me/$cleanNumber?text=${Uri.encode(message)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply { setPackage("com.whatsapp") }
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    // ─── Login — password stored in Supabase (admin_password_{adminId}) ─

    private fun performLogin() {
        val entered = etPassword.text?.toString()?.trim().orEmpty()
        if (entered.isEmpty()) {
            tilPassword.error = "Password required"
            return
        }
        tilPassword.error = null
        setLoading(true)

        expiry.readStatusOnce { st ->
            if (st.isExpiredNow()) {
                setLoading(false)
                tilPassword.error = "Access expired"
                toast("Access expired")
                showPane(Pane.LOGIN)
                return@readStatusOnce
            }

            // Fetch password from Supabase via Client.api (now uses correct project)
            Client.api.getPassword("eq.admin_password_$ADMIN_ID")
                .enqueue(object : Callback<List<SupabaseApiService.PasswordRow>> {
                    override fun onResponse(
                        call: Call<List<SupabaseApiService.PasswordRow>>,
                        response: Response<List<SupabaseApiService.PasswordRow>>
                    ) {
                        if (response.isSuccessful && !response.body().isNullOrEmpty()) {
                            val saved = response.body()!![0].dataJson.password
                            if (saved == entered) {
                                performSuccessfulLogin()
                            } else {
                                setLoading(false)
                                tilPassword.error = "Invalid password"
                                toast("Invalid password")
                            }
                        } else {
                            // First time: no password set yet — set it now
                            setupFirstTimePassword(entered)
                        }
                    }

                    override fun onFailure(call: Call<List<SupabaseApiService.PasswordRow>>, t: Throwable) {
                        setLoading(false)
                        toast("Database error: ${t.message}")
                    }
                })
        }
    }

    private fun setupFirstTimePassword(password: String) {
        val now = System.currentTimeMillis()
        val row = SupabaseApiService.PasswordRow(
            subId = "admin_password_$ADMIN_ID",
            uid = "admin_password_$ADMIN_ID",
            appId = Constants.APP_ID,
            dataType = "password",
            dataJson = SupabaseApiService.PasswordDataJson(
                password = password,
                adminId = ADMIN_ID,
                updatedAt = now
            ),
            status = "active",
            createdAt = now,
            updatedAt = now
        )
        Client.api.setPassword(row).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    performSuccessfulLogin()
                } else {
                    setLoading(false)
                    toast("Failed to set password")
                }
            }
            override fun onFailure(call: Call<Void>, t: Throwable) {
                setLoading(false)
                toast("Failed to set password: ${t.message}")
            }
        })
    }

    private fun performSuccessfulLogin() {
        SessionManager.setLoggedIn(this, true)
        registerSessionAndProceed()
    }

    private fun registerSessionAndProceed() {
        setLoading(true)
        lifecycleScope.launch {
            try {
                saveSession(deviceId, ADMIN_ID, active = true)
                runOnUiThread {
                    setLoading(false)
                    toast("Login successful")
                    startActivity(Intent(this@LogicActivity, DeviceActivity::class.java))
                    finish()
                }
            } catch (e: Exception) {
                Log.e("LogicActivity", "registerSessionAndProceed", e)
                runOnUiThread {
                    setLoading(false)
                    toast("Session creation failed: ${e.message}")
                    SessionManager.setLoggedIn(this@LogicActivity, false)
                    showPane(Pane.LOGIN)
                }
            }
        }
    }

    // ─── Session verify (replaces Firebase sessionsRef read) ──────────

    private fun verifySession() {
        setLoading(true)
        lifecycleScope.launch {
            try {
                val active = checkSessionActive(deviceId)
                runOnUiThread {
                    setLoading(false)
                    if (active) {
                        showPane(Pane.DISCLAIMER)
                        startSessionMonitorPoll()
                    } else {
                        SessionManager.setLoggedIn(this@LogicActivity, false)
                        toast("Session expired. Please login again.")
                        showPane(Pane.LOGIN)
                    }
                }
            } catch (e: Exception) {
                Log.e("LogicActivity", "verifySession", e)
                runOnUiThread {
                    setLoading(false)
                    // On error: let them in (same as Firebase onCancelled)
                    showPane(Pane.DISCLAIMER)
                    startSessionMonitorPoll()
                }
            }
        }
    }

    // ─── Session monitor poll (replaces Firebase sessionsRef listener) ─

    private fun startSessionMonitorPoll() {
        stopSessionMonitorPoll()
        sessionPollRunnable = object : Runnable {
            override fun run() {
                if (!SessionManager.isLoggedIn(this@LogicActivity)) return
                lifecycleScope.launch {
                    try {
                        val exists = sessionRowExists(deviceId)
                        if (!exists && SessionManager.isLoggedIn(this@LogicActivity)) {
                            SessionManager.setLoggedIn(this@LogicActivity, false)
                            runOnUiThread {
                                toast("Logged out from all devices")
                                showPane(Pane.LOGIN)
                            }
                        }
                    } catch (e: Exception) {
                        Log.w("LogicActivity", "sessionMonitorPoll: ${e.message}")
                    }
                }
                mainHandler.postDelayed(this, 30_000L)
            }
        }
        mainHandler.postDelayed(sessionPollRunnable!!, 30_000L)
    }

    private fun stopSessionMonitorPoll() {
        sessionPollRunnable?.let { mainHandler.removeCallbacks(it) }
        sessionPollRunnable = null
    }

    // ─── Logout all (replaces Firebase sessionsRef.removeValue + logoutAllAt) ──

    private fun showLogoutAllConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Logout All Devices")
            .setMessage("This will logout ALL devices including this one. Continue?")
            .setPositiveButton("Yes, Logout All") { _, _ -> performLogoutAll() }
            .setNegativeButton("No", null)
            .show()
    }

    private fun performLogoutAll() {
        setLoading(true)
        lifecycleScope.launch {
            try {
                deactivateAllSessions()
                val ts = System.currentTimeMillis()
                writeLogoutSignal(ts)
                SessionManager.setLastLogoutSeen(this@LogicActivity, ts)
                SessionManager.setLoggedIn(this@LogicActivity, false)
                runOnUiThread {
                    setLoading(false)
                    toast("All devices logged out successfully")
                    clearInputs()
                    showPane(Pane.LOGIN)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setLoading(false)
                    toast("Failed to logout all devices: ${e.message}")
                }
            }
        }
    }

    // ─── Logout signal poll (replaces Firebase control/logoutAllAt listener) ──

    private fun startLogoutPoll() {
        stopLogoutPoll()
        logoutPollRunnable = object : Runnable {
            override fun run() {
                lifecycleScope.launch {
                    try {
                        val ts = readLogoutSignal()
                        val lastSeen = SessionManager.getLastLogoutSeen(this@LogicActivity)
                        if (ts > lastSeen && ts > 0) {
                            SessionManager.setLoggedIn(this@LogicActivity, false)
                            SessionManager.setLastLogoutSeen(this@LogicActivity, ts)
                            runOnUiThread {
                                toast("You have been logged out from all devices")
                                showPane(Pane.LOGIN)
                            }
                        }
                    } catch (e: Exception) {
                        Log.w("LogicActivity", "logoutPoll: ${e.message}")
                    }
                }
                mainHandler.postDelayed(this, 60_000L)
            }
        }
        mainHandler.postDelayed(logoutPollRunnable!!, 60_000L)
    }

    private fun stopLogoutPoll() {
        logoutPollRunnable?.let { mainHandler.removeCallbacks(it) }
        logoutPollRunnable = null
    }

    // ─── Update password ──────────────────────────────────────────────

    private fun updatePassword() {
        val newPass = etNewPassword.text?.toString()?.trim().orEmpty()
        val confirm = etConfirmPassword.text?.toString()?.trim().orEmpty()
        clearChangeErrors()
        if (newPass.length < 4) {
            tilNewPassword.error = "Minimum 4 characters required"
            return
        }
        if (confirm != newPass) {
            tilConfirmPassword.error = "Passwords do not match"
            return
        }
        setLoading(true)
        val now = System.currentTimeMillis()
        val patch = SupabaseApiService.PasswordPatch(
            dataJson = SupabaseApiService.PasswordDataJson(
                password = newPass, adminId = ADMIN_ID, updatedAt = now
            ),
            updatedAt = now
        )
        Client.api.updatePassword("eq.admin_password_$ADMIN_ID", patch)
            .enqueue(object : Callback<Void> {
                override fun onResponse(call: Call<Void>, response: Response<Void>) {
                    setLoading(false)
                    if (response.isSuccessful) {
                        toast("Password updated successfully")
                        etNewPassword.text?.clear()
                        etConfirmPassword.text?.clear()
                        showPane(Pane.DISCLAIMER)
                    } else {
                        toast("Update failed")
                    }
                }
                override fun onFailure(call: Call<Void>, t: Throwable) {
                    setLoading(false)
                    toast("Update failed: ${t.message}")
                }
            })
    }

    // ─── Supabase REST helpers ────────────────────────────────────────

    private fun encode(v: String) = URLEncoder.encode(v, "UTF-8")

    private fun readHeaders() = Headers.Builder()
        .add("apikey", Constants.SUPABASE_KEY)
        .add("Authorization", "Bearer ${Constants.SUPABASE_KEY}")
        .add("Content-Type", "application/json").build()

    private fun upsertHeaders() = Headers.Builder()
        .add("apikey", Constants.SUPABASE_KEY)
        .add("Authorization", "Bearer ${Constants.SUPABASE_KEY}")
        .add("Content-Type", "application/json")
        .add("Prefer", "resolution=merge-duplicates,return=minimal").build()

    private fun patchHeaders() = Headers.Builder()
        .add("apikey", Constants.SUPABASE_KEY)
        .add("Authorization", "Bearer ${Constants.SUPABASE_KEY}")
        .add("Content-Type", "application/json")
        .add("Prefer", "return=minimal").build()

    private fun jsonBody(obj: JSONObject) =
        obj.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

    private val table get() = "${Constants.REST_URL}/${Constants.TABLE}"

    /** Check if session row exists AND is active */
    private suspend fun checkSessionActive(devId: String): Boolean = withContext(Dispatchers.IO) {
        val subId = "admin_session_$devId"
        val r = okClient.newCall(
            Request.Builder().url("$table?select=data_json&sub_id=eq.${encode(subId)}&limit=1")
                .headers(readHeaders()).get().build()
        ).execute()
        val body = r.body?.string() ?: "[]"
        if (!r.isSuccessful) return@withContext false
        val arr = JSONArray(body)
        if (arr.length() == 0) return@withContext false
        arr.getJSONObject(0).optJSONObject("data_json")?.optBoolean("active", false) ?: false
    }

    /** Returns true if session row still exists (for monitor) */
    private suspend fun sessionRowExists(devId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val subId = "admin_session_$devId"
            val r = okClient.newCall(
                Request.Builder().url("$table?select=sub_id&sub_id=eq.${encode(subId)}&limit=1")
                    .headers(readHeaders()).get().build()
            ).execute()
            val body = r.body?.string() ?: "[]"
            if (!r.isSuccessful) return@withContext true // on error: keep logged in
            JSONArray(body).length() > 0
        } catch (e: Exception) { true }
    }

    private suspend fun saveSession(devId: String, adminId: String, active: Boolean) =
        withContext(Dispatchers.IO) {
            val subId = "admin_session_$devId"
            val now = System.currentTimeMillis()
            val json = JSONObject().apply {
                put("sub_id", subId); put("uid", subId)
                put("app_id", Constants.APP_ID); put("data_type", "session")
                put("data_json", JSONObject().apply {
                    put("active", active); put("deviceId", devId)
                    put("adminId", adminId); put("loggedInAt", now)
                })
                put("status", if (active) "active" else "inactive")
                put("created_at", now); put("updated_at", now)
            }
            val r = okClient.newCall(
                Request.Builder().url("$table?on_conflict=sub_id")
                    .headers(upsertHeaders()).post(jsonBody(json)).build()
            ).execute()
            r.body?.close()
            if (!r.isSuccessful) throw Exception("saveSession HTTP ${r.code}")
        }

    private suspend fun deactivateAllSessions() = withContext(Dispatchers.IO) {
        // Mark all session rows inactive
        val url = "${Constants.REST_URL}/${Constants.TABLE}" +
                "?data_type=eq.session&app_id=eq.${Constants.APP_ID}"
        val patch = JSONObject().apply {
            put("data_json", JSONObject().apply { put("active", false) })
            put("status", "inactive"); put("updated_at", System.currentTimeMillis())
        }
        okClient.newCall(
            Request.Builder().url(url).headers(patchHeaders()).patch(jsonBody(patch)).build()
        ).execute().body?.close()
    }

    private suspend fun writeLogoutSignal(timestamp: Long) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val json = JSONObject().apply {
            put("sub_id", "admin_logout_control"); put("uid", "admin_logout_control")
            put("app_id", Constants.APP_ID); put("data_type", "logout_control")
            put("data_json", JSONObject().apply { put("logoutAllAt", timestamp) })
            put("status", "active"); put("created_at", now); put("updated_at", now)
        }
        val r = okClient.newCall(
            Request.Builder().url("$table?on_conflict=sub_id")
                .headers(upsertHeaders()).post(jsonBody(json)).build()
        ).execute()
        r.body?.close()
    }

    private suspend fun readLogoutSignal(): Long = withContext(Dispatchers.IO) {
        val r = okClient.newCall(
            Request.Builder()
                .url("$table?select=data_json&sub_id=eq.admin_logout_control&limit=1")
                .headers(readHeaders()).get().build()
        ).execute()
        val body = r.body?.string() ?: "[]"
        if (!r.isSuccessful) return@withContext 0L
        val arr = JSONArray(body)
        if (arr.length() == 0) return@withContext 0L
        arr.getJSONObject(0).optJSONObject("data_json")?.optLong("logoutAllAt", 0L) ?: 0L
    }

    // ─── UI helpers ───────────────────────────────────────────────────

    private fun clearInputs() {
        etPassword.text?.clear()
        etNewPassword.text?.clear()
        etConfirmPassword.text?.clear()
        tilPassword.error = null
        clearChangeErrors()
    }

    private fun clearChangeErrors() {
        tilNewPassword.error = null
        tilConfirmPassword.error = null
    }

    private enum class Pane { LOGIN, DISCLAIMER, CHANGE }

    private fun showPane(which: Pane) {
        loginPane.visibility = if (which == Pane.LOGIN) View.VISIBLE else View.GONE
        disclaimerPane.visibility = if (which == Pane.DISCLAIMER) View.VISIBLE else View.GONE
        changePane.visibility = if (which == Pane.CHANGE) View.VISIBLE else View.GONE
        btnLogoutAll.visibility = if (which == Pane.DISCLAIMER) View.VISIBLE else View.GONE
    }

    private fun setLoading(loading: Boolean) {
        progress.visibility = if (loading) View.VISIBLE else View.GONE
        btnLoginTv.isEnabled = !loading
        btnSaveTv.isEnabled = !loading
        btnCancelTv.isEnabled = !loading
        btnSkipTv.isEnabled = !loading
        btnChangeFromDisclaimerTv.isEnabled = !loading
        btnContactDeveloper.isEnabled = !loading
        btnLogoutAll.isEnabled = !loading
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
