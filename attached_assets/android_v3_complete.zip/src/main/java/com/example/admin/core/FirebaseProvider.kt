package com.example.admin.core

// FirebaseProvider — sirf FCM push notifications ke liye rakha gaya hai.
// Firebase Realtime Database ka koi bhi use nahi.
// Sabhi data (devices, sessions, expiry, passwords, SMS) Supabase se aata hai.
// FCM auto-init hota hai google-services.json se.
object FirebaseProvider
