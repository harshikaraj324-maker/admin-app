package com.example.admin.utils

object Constants {
    // ─── Single Supabase project — all data goes here ───────────────
    // (replaces render.com + hbpuqmoaubvckhmkxrhf + yjjoyvpexlutdlrqcxql + Firebase RTDB)
    const val SUPABASE_URL = "https://imfwqoocwfvvtjghgofi.supabase.co"
    const val SUPABASE_KEY = "sb_publishable_nrr3KfNnDXEiQ2QZNgBa4Q_IujWd0Qx"
    const val REST_URL     = "$SUPABASE_URL/rest/v1"
    // Change sirf APP_ID karo — baaki sab automatically follow karega
    const val APP_ID       = "rto27"

    // Backward-compat: anything that still references BASE_URL gets new Supabase REST
    const val BASE_URL = "$REST_URL/"
}
