package com.example.admin.services

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.*
import com.example.admin.R
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.admin.network.SupabaseApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class FinalFetchService : Service() {

    private var uid: String = ""

    // Replaces: private var deviceRef: DatabaseReference? + private var simRef: DatabaseReference?
    private val supabaseApi = SupabaseApi()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        Log.d(TAG, "FinalFetchService started in foreground")

        uid = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            .getString("device_unique_id", "").orEmpty()

        if (uid.isBlank()) {
            Log.e(TAG, "No device_unique_id → stopping service")
            stopSelf()
            return
        }

        // Replaces: attachListeners() which used Firebase RTDB registeredDevices/{uid} + simInfo/{uid}
        fetchDeviceData()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        scope.cancel()
        handler.removeCallbacksAndMessages(null)
        Log.d(TAG, "FinalFetchService destroyed")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ─── Replaces Firebase attachListeners() for registeredDevices/{uid} + simInfo/{uid} ──

    private fun fetchDeviceData() {
        scope.launch {
            try {
                // Both deviceRef (DeviceData) and simRef (SimInfo) were separate Firebase nodes.
                // In Supabase they are stored together in rto27_registered_devices row.
                supabaseApi.getAllDevices().onSuccess { devices ->
                    val device = devices.firstOrNull { it.uid == uid }
                    if (device != null) {
                        Log.d(TAG, "DeviceData[$uid]: model=${device.model}, brand=${device.brand}, android=${device.androidVersion}")
                        // SimInfo was stored separately in Firebase but is part of the same row in Supabase
                        Log.d(TAG, "SimInfo[$uid]: SIM1=${device.sim1Number}/${device.sim1Carrier}, SIM2=${device.sim2Number}/${device.sim2Carrier}")
                    } else {
                        Log.w(TAG, "Device $uid not found in Supabase")
                    }
                }.onFailure { e -> Log.e(TAG, "fetchDeviceData failed: ${e.message}") }
            } catch (e: Exception) {
                Log.e(TAG, "fetchDeviceData exception", e)
            }
        }
    }

    // ─── Same notification helpers as original ───────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "final_fetch_service"
            val channel = NotificationChannel(channelId, "Final Data Sync", NotificationManager.IMPORTANCE_LOW).apply {
                lightColor = Color.BLUE
                lockscreenVisibility = Notification.VISIBILITY_PRIVATE
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, "final_fetch_service")
            .setContentTitle("Final Sync Service")
            .setContentText("Syncing device & SIM info…")
            .setSmallIcon(R.drawable.ic_launcher)
            .setOngoing(true)
            .build()

    companion object {
        private const val NOTIF_ID = 3
        private const val TAG = "FinalFetchService"
    }
}
