package com.example.admin.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import com.example.admin.R
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.admin.network.SupabaseApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class DataFetchService : Service() {

    companion object {
        private const val TAG = "DataFetchService"
        private const val NOTIF_ID = 12001
        private const val CHANNEL_ID = "data_fetch_service_channel"
        private const val OVERVIEW_TICK_MS = 5_000L   // same as original
        private const val POLL_INTERVAL_MS = 30_000L  // replaces Firebase realtime listeners
    }

    private val supabaseApi = SupabaseApi()

    // Same in-memory state as original
    private val registeredDevices = CopyOnWriteArrayList<String>()
    private val statusMap = ConcurrentHashMap<String, Boolean>()

    // Same overview scheduler as original
    private val scheduler = Executors.newScheduledThreadPool(1)
    private var overviewFuture: ScheduledFuture<*>? = null

    private val destroyed = AtomicBoolean(false)
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannelIfNeeded()
        startForeground(NOTIF_ID, buildNotification("Monitoring device status"))

        // Start Supabase polling (replaces Firebase ChildEventListener + ValueEventListener)
        startPolling()

        // Same overview logger as original
        overviewFuture = scheduler.scheduleAtFixedRate({
            try { logOverview() } catch (t: Throwable) { Log.e(TAG, "Overview tick error", t) }
        }, 0, OVERVIEW_TICK_MS, TimeUnit.MILLISECONDS)

        Log.d(TAG, "Service created and foreground started")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        destroyed.set(true)
        scope.cancel()
        try { overviewFuture?.cancel(true) } catch (_: Throwable) {}
        try { scheduler.shutdownNow() } catch (_: Throwable) {}
        stopForeground(true)
        Log.d(TAG, "Service destroyed")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ─── Supabase polling (replaces Firebase ChildEventListener on registeredDevices + status) ──

    private fun startPolling() {
        scope.launch {
            while (isActive && !destroyed.get()) {
                try { refreshFromSupabase() }
                catch (t: Throwable) { Log.e(TAG, "Poll error", t) }
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    private suspend fun refreshFromSupabase() {
        // Replaces: dbRefData (registeredDevices) ValueEventListener.onDataChange
        supabaseApi.getAllDevices().onSuccess { devices ->
            registeredDevices.clear()
            devices.forEach { registeredDevices.add(it.uid) }
            Log.d(TAG, "registeredDevices updated size=${registeredDevices.size}")
        }.onFailure { e -> Log.w(TAG, "getAllDevices failed: ${e.message}") }

        // Replaces: dbRefStatus (status / deviceStatusUpdates) ChildEventListener
        supabaseApi.getLatestDeviceStatuses().onSuccess { statusesMap ->
            statusMap.clear()
            statusesMap.forEach { (uid, status) ->
                statusMap[uid] = status.online
                Log.d(TAG, "STATUS updated: $uid -> ${status.online}")
            }
        }.onFailure { e -> Log.w(TAG, "getLatestDeviceStatuses failed: ${e.message}") }
    }

    // ─── Same overview logger as original ───────────────────────

    private fun logOverview() {
        try {
            val online  = statusMap.filter { it.value }.keys.toList()
            val offline = statusMap.filter { !it.value }.keys.toList()
            Log.d(TAG, "=== OVERVIEW ===")
            Log.d(TAG, "Registered devices: ${registeredDevices.size}")
            Log.d(TAG, "Online devices(${online.size}): $online")
            Log.d(TAG, "Offline devices(${offline.size}): $offline")
            Log.d(TAG, "================")
        } catch (e: Exception) { Log.w(TAG, "logOverview error: ${e.message}") }
    }

    // ─── Same notification helpers as original ───────────────────

    private fun createNotificationChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val nm = getSystemService(NotificationManager::class.java)
                val ch = NotificationChannel(CHANNEL_ID, "Data Fetch Service", NotificationManager.IMPORTANCE_LOW)
                ch.description = "Monitors device status"
                nm.createNotificationChannel(ch)
            } catch (e: Exception) { Log.w(TAG, "createNotificationChannel error: ${e.message}") }
        }
    }

    private fun buildNotification(text: String = "Device monitor running"): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Device Monitor")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher)
            .setOngoing(true)
            .build()
}
