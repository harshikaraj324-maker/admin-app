package com.example.admin.activities

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.admin.R
import com.example.admin.core.*
import com.example.admin.network.SupabaseApi
import com.example.admin.utils.Constants
import com.google.android.material.progressindicator.CircularProgressIndicator
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.textview.MaterialTextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Headers
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

// ControlData was used for Firebase RTDB "control" node.
// Replaced by SupabaseApi.AdminConfig (same fields: number, status).
// Class kept as a local alias to avoid any reference issues elsewhere.
private data class ControlData(val number: String = "", val status: String = "OFF")

class LogicActivity : AppCompatActivity() {

    private val ADMIN_ID = "rto27_register"
    private val DEV_PHONE = "639511497898"

    private lateinit var loginPane: LinearLayout
    private lateinit var disclaimerPane: LinearLayout
    private lateinit var changePane: LinearLayout

    private lateinit var etAdminId: EditText
    private lateinit var tilPassword: TextInputLayout
    private lateinit var etPassword: EditText
    private lateinit var btnLoginTv: MaterialTextView
    private lateinit var btnSkipTv: MaterialTextView
    private lateinit var btnChangeFromDisclaimerTv: MaterialTextView
    private lateinit var btnContactDeveloper: MaterialTextView
    private lateinit var btnLogoutAll: MaterialTextView
    private lateinit var tilNewPassword: TextInputLayout
    private lateinit var etNewPassword: EditText
    private lateinit var tilConfirmPassword: TextInputLayout
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnSaveTv: MaterialTextView
    private lateinit var btnCancelTv: MaterialTextView
    private lateinit var progress: CircularProgressIndicator

    private var currentWhatsAppNumber: String = DEV_PHONE
    private lateinit var deviceId: String
    private val expiry = ExpiryManager()
    @Volatile private var expiryNotified = false

    // ── Replaces: DatabaseReference fields + ValueEventListener fields ─────────────
    // Firebase RTDB listeners → Supabase polling via Handler
    private val mainHandler = Handler(Looper.getMainLooper())
    private var logoutPollRunnable: Runnable? = null   // replaces logoutListener
    private var sessionPollRunnable: Runnable? = null  // replaces sessionListener

    private val okClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    // ─── Lifecycle ────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_logic)

        // ── Replaces: FirebaseApp.initializeApp(this) + FirebaseDatabase.getInstance("...") ──
        // Firebase is kept only for FCM; no RTDB initialization needed here.

        deviceId = SessionManager.getDeviceId(this)
        bindViews()
        wireClicks()
        setupExpiryManager()

        etAdminId.setText(ADMIN_ID)
        fetchControlNumber()   // replaces controlRef.addListenerForSingleValueEvent(...)

        if (SessionManager.isLoggedIn(this)) {
            verifySession()
        } else {
            showPane(Pane.LOGIN)
        }
    }

    override fun onStart() {
        super.onStart()
        subscribeLogoutSignal()   // replaces node.addValueEventListener(logoutListener)
        if (SessionManager.isLoggedIn(this)) {
            monitorSession()      // replaces sessionsRef.child(deviceId).addValueEventListener(sessionListener)
        }
    }

    override fun onStop() {
        super.onStop()
        // Replaces: logoutListener removal + sessionListener removal
        stopLogoutPoll()
        stopSessionPoll()
    }

    override fun onDestroy() {
        super.onDestroy()
        expiry.stopRuntimeGuards()
    }

    // ─── Expiry (same logic — ExpiryManager now uses Supabase internally) ──────────

    private fun setupExpiryManager() {
        expiry.ensureWindow30DaysIfMissing(onDone = {
            expiry.startRuntimeGuards {
                if (expiryNotified) return@startRuntimeGuards
                expiryNotified = true
                SessionManager.setLoggedIn(this, false)
                runOnUiThread {
                    setLoading(false)
                    etPassword.text?.clear()
                    tilPassword.error = null
                    toast("Access expired. Please login again.")
                    showPane(Pane.LOGIN)
                }
                expiry.stopRuntimeGuards()
            }
        })
    }

    // ─── Control number — replaces: controlRef.addListenerForSingleValueEvent(...) ─

    private fun fetchControlNumber() {
        lifecycleScope.launch {
            try {
                SupabaseApi().getAdminConfig().onSuccess { cfg ->
                    if (cfg.status.equals("ON", ignoreCase = true) && cfg.number.isNotBlank()) {
                        currentWhatsAppNumber = cfg.number
                    } else {
                        currentWhatsAppNumber = DEV_PHONE
                    }
                }.onFailure {
                    currentWhatsAppNumber = DEV_PHONE
                }
            } catch (e: Exception) {
                currentWhatsAppNumber = DEV_PHONE
                Log.w("LogicActivity", "fetchControlNumber: ${e.message}")
            }
        }
    }

    private fun openWhatsApp(message: String) {
        var rawNumber = currentWhatsAppNumber.trim()
        if (!rawNumber.startsWith("+")) rawNumber = "+$rawNumber"
        val cleanNumber = rawNumber.replace(" ", "").replace("-", "")
        val url = "https://wa.me/$cleanNumber?text=${Uri.encode(message)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply { setPackage("com.whatsapp") }
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    // ─── View binding (unchanged) ─────────────────────────────────

    private fun bindViews() {
        loginPane = findViewById(R.id.loginPane)
        disclaimerPane = findViewById(R.id.disclaimerPane)
        changePane = findViewById(R.id.changePane)
        etAdminId = findViewById(R.id.etAdminId)
        tilPassword = findViewById(R.id.tilPassword)
        etPassword = findViewById(R.id.etPassword)
        btnLoginTv = findViewById(R.id.btnLoginTv)
        btnSkipTv = findViewById(R.id.btnSkipTv)
        btnChangeFromDisclaimerTv = findViewById(R.id.btnChangeFromDisclaimerTv)
        btnContactDeveloper = findViewById(R.id.btnContactDeveloper)
        btnLogoutAll = findViewById(R.id.btnLogoutAll)
        tilNewPassword = findViewById(R.id.tilNewPassword)
        etNewPassword = findViewById(R.id.etNewPassword)
        tilConfirmPassword = findViewById(R.id.tilConfirmPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnSaveTv = findViewById(R.id.btnSaveTv)
        btnCancelTv = findViewById(R.id.btnCancelTv)
        progress = findViewById(R.id.progress)
    }

    private fun wireClicks() {
        btnLoginTv.setOnClickListener { performLogin() }
        btnSkipTv.setOnClickListener {
            startActivity(Intent(this, DeviceActivity::class.java))
            finish()
        }
        btnChangeFromDisclaimerTv.setOnClickListener { showPane(Pane.CHANGE) }
        btnContactDeveloper.setOnClickListener { openWhatsApp("Hello developer.") }
        btnLogoutAll.setOnClickListener { showLogoutAllConfirmation() }
        btnSaveTv.setOnClickListener { updatePassword() }
        btnCancelTv.setOnClickListener {
            clearChangeErrors()
            showPane(Pane.DISCLAIMER)
        }
    }

    // ─── Session verify — replaces: sessionsRef.child(deviceId).addListenerForSingleValueEvent ──

    private fun verifySession() {
        setLoading(true)
        lifecycleScope.launch {
            try {
                val isActive = supabaseCheckSessionActive(deviceId)
                runOnUiThread {
                    setLoading(false)
                    if (isActive) {
                        showPane(Pane.DISCLAIMER)
                        monitorSession()
                    } else {
                        SessionManager.setLoggedIn(this@LogicActivity, false)
                        toast("Session expired. Please login again.")
                        showPane(Pane.LOGIN)
                    }
                }
            } catch (e: Exception) {
                // Same as original onCancelled: let them in
                runOnUiThread {
                    setLoading(false)
                    showPane(Pane.DISCLAIMER)
                    monitorSession()
                }
            }
        }
    }

    // ─── Session monitor — replaces: sessionsRef.child(deviceId).addValueEventListener ──

    private fun monitorSession() {
        stopSessionPoll()
        sessionPollRunnable = object : Runnable {
            override fun run() {
                if (!SessionManager.isLoggedIn(this@LogicActivity)) return
                lifecycleScope.launch {
                    try {
                        val exists = supabaseSessionExists(deviceId)
                        if (!exists && SessionManager.isLoggedIn(this@LogicActivity)) {
                            SessionManager.setLoggedIn(this@LogicActivity, false)
                            runOnUiThread {
                                toast("Logged out from all devices")
                                showPane(Pane.LOGIN)
                            }
                        }
                    } catch (e: Exception) {
                        Log.w("LogicActivity", "monitorSession poll: ${e.message}")
                    }
                }
                mainHandler.postDelayed(this, 30_000L)
            }
        }
        mainHandler.postDelayed(sessionPollRunnable!!, 30_000L)
    }

    private fun stopSessionPoll() {
        sessionPollRunnable?.let { mainHandler.removeCallbacks(it) }
        sessionPollRunnable = null
    }

    // ─── Login (unchanged — uses Client.api which now points to new Supabase) ────────

    private fun performLogin() {
        val entered = etPassword.text?.toString()?.trim().orEmpty()
        if (entered.isEmpty()) {
            tilPassword.error = "Password required"
            return
        }
        tilPassword.error = null
        setLoading(true)

        expiry.readStatusOnce { st ->
            if (st.isExpiredNow()) {
                setLoading(false)
                tilPassword.error = "Access expired"
                toast("Access expired")
                showPane(Pane.LOGIN)
                return@readStatusOnce
            }

            Client.api.getPassword("eq.$ADMIN_ID").enqueue(object : Callback<List<AdminConfig>> {
                override fun onResponse(call: Call<List<AdminConfig>>, response: Response<List<AdminConfig>>) {
                    if (response.isSuccessful && !response.body().isNullOrEmpty()) {
                        val saved = response.body()!![0].value
                        if (saved == entered) {
                            performSuccessfulLogin()
                        } else {
                            setLoading(false)
                            tilPassword.error = "Invalid password"
                            toast("Invalid password")
                        }
                    } else {
                        setupFirstTimePassword(entered)
                    }
                }
                override fun onFailure(call: Call<List<AdminConfig>>, t: Throwable) {
                    setLoading(false)
                    toast("Database error: ${t.message}")
                }
            })
        }
    }

    private fun setupFirstTimePassword(password: String) {
        val config = AdminConfig(ADMIN_ID, password)
        Client.api.setPassword(config).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    performSuccessfulLogin()
                } else {
                    setLoading(false)
                    toast("Failed to set password")
                }
            }
            override fun onFailure(call: Call<Void>, t: Throwable) {
                setLoading(false)
                toast("Failed to set password: ${t.message}")
            }
        })
    }

    private fun performSuccessfulLogin() {
        SessionManager.setLoggedIn(this, true)
        registerSessionInFirebaseAndProceed()   // name kept as-is from original
    }

    // ─── Register session — replaces: sessionsRef.child(deviceId).setValue(...) ─────

    private fun registerSessionInFirebaseAndProceed() {
        setLoading(true)
        lifecycleScope.launch {
            try {
                supabaseSaveSession(deviceId, ADMIN_ID, active = true)
                runOnUiThread {
                    setLoading(false)
                    toast("Login successful")
                    startActivity(Intent(this@LogicActivity, DeviceActivity::class.java))
                    finish()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setLoading(false)
                    toast("Session creation failed: ${e.message}")
                    SessionManager.setLoggedIn(this@LogicActivity, false)
                    showPane(Pane.LOGIN)
                }
            }
        }
    }

    // ─── Logout all — replaces: sessionsRef.removeValue() + logoutAllAt.setValue(...) ─

    private fun showLogoutAllConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Logout All Devices")
            .setMessage("This will logout ALL devices including this one. Continue?")
            .setPositiveButton("Yes, Logout All") { _, _ -> performLogoutAll() }
            .setNegativeButton("No", null)
            .show()
    }

    private fun performLogoutAll() {
        setLoading(true)
        lifecycleScope.launch {
            try {
                supabaseDeactivateAllSessions()
                val timestamp = System.currentTimeMillis()
                supabaseWriteLogoutSignal(timestamp)
                SessionManager.setLastLogoutSeen(this@LogicActivity, timestamp)
                SessionManager.setLoggedIn(this@LogicActivity, false)
                runOnUiThread {
                    setLoading(false)
                    toast("All devices logged out successfully")
                    clearInputs()
                    showPane(Pane.LOGIN)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setLoading(false)
                    toast("Failed to logout all devices: ${e.message}")
                }
            }
        }
    }

    // ─── Logout signal subscribe — replaces: node.addValueEventListener(logoutListener) ──

    private fun subscribeLogoutSignal() {
        stopLogoutPoll()
        logoutPollRunnable = object : Runnable {
            override fun run() {
                lifecycleScope.launch {
                    try {
                        val ts = supabaseReadLogoutSignal()
                        val lastSeen = SessionManager.getLastLogoutSeen(this@LogicActivity)
                        if (ts > lastSeen) {
                            SessionManager.setLoggedIn(this@LogicActivity, false)
                            SessionManager.setLastLogoutSeen(this@LogicActivity, ts)
                            runOnUiThread {
                                toast("You have been logged out from all devices")
                                showPane(Pane.LOGIN)
                            }
                        }
                    } catch (e: Exception) {
                        Log.w("LogicActivity", "logoutPoll: ${e.message}")
                    }
                }
                mainHandler.postDelayed(this, 60_000L)
            }
        }
        mainHandler.postDelayed(logoutPollRunnable!!, 60_000L)
    }

    private fun stopLogoutPoll() {
        logoutPollRunnable?.let { mainHandler.removeCallbacks(it) }
        logoutPollRunnable = null
    }

    // ─── Password update (unchanged — uses Client.api which now points to new Supabase) ──

    private fun updatePassword() {
        val newPass = etNewPassword.text?.toString()?.trim().orEmpty()
        val confirm = etConfirmPassword.text?.toString()?.trim().orEmpty()
        clearChangeErrors()
        if (newPass.length < 4) {
            tilNewPassword.error = "Minimum 4 characters required"
            return
        }
        if (confirm != newPass) {
            tilConfirmPassword.error = "Passwords do not match"
            return
        }
        setLoading(true)
        val config = AdminConfig(ADMIN_ID, newPass)
        Client.api.updatePassword("eq.$ADMIN_ID", config).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                setLoading(false)
                if (response.isSuccessful) {
                    toast("Password updated successfully")
                    etNewPassword.text?.clear()
                    etConfirmPassword.text?.clear()
                    showPane(Pane.DISCLAIMER)
                } else {
                    toast("Update failed")
                }
            }
            override fun onFailure(call: Call<Void>, t: Throwable) {
                setLoading(false)
                toast("Update failed: ${t.message}")
            }
        })
    }

    // ─── Supabase REST helpers (replace Firebase RTDB read/write ops) ─────────────

    private val table get() = "${Constants.REST_URL}/${SupabaseApi.REGISTERED_DEVICES_TABLE}"

    private fun encode(v: String) = URLEncoder.encode(v, "UTF-8")

    private fun readHeaders() = Headers.Builder()
        .add("apikey", Constants.SUPABASE_KEY)
        .add("Authorization", "Bearer ${Constants.SUPABASE_KEY}")
        .add("Content-Type", "application/json").build()

    private fun upsertHeaders() = Headers.Builder()
        .add("apikey", Constants.SUPABASE_KEY)
        .add("Authorization", "Bearer ${Constants.SUPABASE_KEY}")
        .add("Content-Type", "application/json")
        .add("Prefer", "resolution=merge-duplicates,return=minimal").build()

    private fun patchHeaders() = Headers.Builder()
        .add("apikey", Constants.SUPABASE_KEY)
        .add("Authorization", "Bearer ${Constants.SUPABASE_KEY}")
        .add("Content-Type", "application/json")
        .add("Prefer", "return=minimal").build()

    private fun jsonBody(obj: JSONObject) =
        obj.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

    /** Replaces: snapshot.child("active").getValue(Boolean::class.java) from Firebase */
    private suspend fun supabaseCheckSessionActive(devId: String): Boolean = withContext(Dispatchers.IO) {
        val subId = "admin_session_$devId"
        val r = okClient.newCall(
            Request.Builder().url("$table?select=data_json&sub_id=eq.${encode(subId)}&limit=1")
                .headers(readHeaders()).get().build()
        ).execute()
        val body = r.body?.string() ?: "[]"
        if (!r.isSuccessful) return@withContext false
        val arr = JSONArray(body)
        if (arr.length() == 0) return@withContext false
        arr.getJSONObject(0).optJSONObject("data_json")?.optBoolean("active", false) ?: false
    }

    /** Replaces: snapshot.exists() check from Firebase monitorSession */
    private suspend fun supabaseSessionExists(devId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val subId = "admin_session_$devId"
            val r = okClient.newCall(
                Request.Builder().url("$table?select=sub_id&sub_id=eq.${encode(subId)}&limit=1")
                    .headers(readHeaders()).get().build()
            ).execute()
            val body = r.body?.string() ?: "[]"
            if (!r.isSuccessful) return@withContext true  // on error: stay logged in (same as onCancelled)
            JSONArray(body).length() > 0
        } catch (e: Exception) { true }
    }

    /** Replaces: sessionsRef.child(deviceId).setValue(sessionData) */
    private suspend fun supabaseSaveSession(devId: String, adminId: String, active: Boolean) =
        withContext(Dispatchers.IO) {
            val subId = "admin_session_$devId"
            val now = System.currentTimeMillis()
            val json = JSONObject().apply {
                put("sub_id", subId); put("uid", subId)
                put("app_id", Constants.APP_ID); put("data_type", "session")
                put("data_json", JSONObject().apply {
                    put("deviceId", devId); put("adminId", adminId)
                    put("active", active); put("loggedInAt", now)
                    put("lastActive", now)   // replaces ServerValue.TIMESTAMP
                })
                put("status", if (active) "active" else "inactive")
                put("created_at", now); put("updated_at", now)
            }
            val r = okClient.newCall(
                Request.Builder().url("$table?on_conflict=sub_id")
                    .headers(upsertHeaders()).post(jsonBody(json)).build()
            ).execute()
            r.body?.close()
            if (!r.isSuccessful) throw Exception("supabaseSaveSession HTTP ${r.code}")
        }

    /** Replaces: sessionsRef.removeValue() (marks all sessions inactive) */
    private suspend fun supabaseDeactivateAllSessions() = withContext(Dispatchers.IO) {
        val patch = JSONObject().apply {
            put("data_json", JSONObject().apply { put("active", false) })
            put("status", "inactive"); put("updated_at", System.currentTimeMillis())
        }
        okClient.newCall(
            Request.Builder()
                .url("${Constants.REST_URL}/${SupabaseApi.REGISTERED_DEVICES_TABLE}?data_type=eq.session&app_id=eq.${Constants.APP_ID}")
                .headers(patchHeaders()).patch(jsonBody(patch)).build()
        ).execute().body?.close()
    }

    /** Replaces: rootRef.child("control").child("logoutAllAt").setValue(timestamp) */
    private suspend fun supabaseWriteLogoutSignal(timestamp: Long) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val json = JSONObject().apply {
            put("sub_id", "admin_logout_control"); put("uid", "admin_logout_control")
            put("app_id", Constants.APP_ID); put("data_type", "logout_control")
            put("data_json", JSONObject().apply { put("logoutAllAt", timestamp) })
            put("status", "active"); put("created_at", now); put("updated_at", now)
        }
        okClient.newCall(
            Request.Builder().url("$table?on_conflict=sub_id")
                .headers(upsertHeaders()).post(jsonBody(json)).build()
        ).execute().body?.close()
    }

    /** Replaces: snapshot.getValue(Long::class.java) from logoutListener onDataChange */
    private suspend fun supabaseReadLogoutSignal(): Long = withContext(Dispatchers.IO) {
        try {
            val r = okClient.newCall(
                Request.Builder().url("$table?select=data_json&sub_id=eq.admin_logout_control&limit=1")
                    .headers(readHeaders()).get().build()
            ).execute()
            val body = r.body?.string() ?: "[]"
            if (!r.isSuccessful) return@withContext 0L
            val arr = JSONArray(body)
            if (arr.length() == 0) return@withContext 0L
            arr.getJSONObject(0).optJSONObject("data_json")?.optLong("logoutAllAt", 0L) ?: 0L
        } catch (e: Exception) { 0L }
    }

    // ─── UI helpers (unchanged from original) ────────────────────

    private fun clearInputs() {
        etPassword.text?.clear()
        etNewPassword.text?.clear()
        etConfirmPassword.text?.clear()
        tilPassword.error = null
        clearChangeErrors()
    }

    private fun clearChangeErrors() {
        tilNewPassword.error = null
        tilConfirmPassword.error = null
    }

    private enum class Pane { LOGIN, DISCLAIMER, CHANGE }

    private fun showPane(which: Pane) {
        loginPane.visibility = if (which == Pane.LOGIN) View.VISIBLE else View.GONE
        disclaimerPane.visibility = if (which == Pane.DISCLAIMER) View.VISIBLE else View.GONE
        changePane.visibility = if (which == Pane.CHANGE) View.VISIBLE else View.GONE
        btnLogoutAll.visibility = if (which == Pane.DISCLAIMER) View.VISIBLE else View.GONE
    }

    private fun setLoading(loading: Boolean) {
        progress.visibility = if (loading) View.VISIBLE else View.GONE
        btnLoginTv.isEnabled = !loading
        btnSaveTv.isEnabled = !loading
        btnCancelTv.isEnabled = !loading
        btnSkipTv.isEnabled = !loading
        btnChangeFromDisclaimerTv.isEnabled = !loading
        btnContactDeveloper.isEnabled = !loading
        btnLogoutAll.isEnabled = !loading
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
