package com.example.admin.core

// FirebaseProvider — Firebase RTDB has been removed.
// All data now comes from Supabase (imfwqoocwfvvtjghgofi).
// Firebase is kept ONLY for FCM push-notification delivery (google-services.json).
// This file is intentionally empty — do not add RTDB references here.
object FirebaseProvider
