package com.example.admin.core

import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

object FirebaseProvider {
    private const val DB_URL = "https://session-68318-default-rtdb.firebaseio.com/"

    fun getDatabase(): FirebaseDatabase {
        return FirebaseDatabase.getInstance(DB_URL)
    }

    fun getReference(path: String = ""): DatabaseReference {
        val db = getDatabase()
        return if (path.isEmpty()) db.reference else db.reference.child(path)
    }
}