package com.example.admin.core

import retrofit2.Call
import retrofit2.http.*

interface SupabaseApiService {
    @GET("admin_config")
    fun getPassword(@Query("key") key: String): Call<List<AdminConfig>>

    @POST("admin_config")
    fun setPassword(@Body config: AdminConfig): Call<Void>

    @PATCH("admin_config")
    fun updatePassword(@Query("key") key: String, @Body config: AdminConfig): Call<Void>
}