package com.example.admin.core

data class AdminConfig(
    val key: String,
    val value: String
)