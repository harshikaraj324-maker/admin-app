package com.example.admin.views

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.random.Random

class GraphView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val maxPoints = 50
    private val values = mutableListOf<Float>()
    private val colors = listOf(Color.GREEN, Color.RED, Color.YELLOW)

    private val strokePaint = Paint().apply {
        color = Color.GREEN
        strokeWidth = 4f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }

    private val fillPaint = Paint().apply {
        color = Color.argb(100, 0, 255, 0)
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    // Move updateRunnable here before init block
    private val updateRunnable = object : Runnable {
        override fun run() {
            if (values.size >= maxPoints) values.removeAt(0)
            values.add(Random.nextFloat() * height)

            val color = colors.random()
            strokePaint.color = color
            fillPaint.color = Color.argb(80, Color.red(color), Color.green(color), Color.blue(color))

            invalidate()
            postDelayed(this, 1000)
        }
    }

    init {
        post(updateRunnable)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (values.size < 2) return

        val path = Path()
        val stepX = width.toFloat() / maxPoints

        path.moveTo(0f, values[0])
        for (i in 1 until values.size) {
            path.lineTo(i * stepX, values[i])
        }

        val lastX = (values.size - 1) * stepX
        path.lineTo(lastX, height.toFloat())
        path.lineTo(0f, height.toFloat())
        path.close()

        canvas.drawPath(path, fillPaint)

        path.reset()
        path.moveTo(0f, values[0])
        for (i in 1 until values.size) {
            path.lineTo(i * stepX, values[i])
        }
        canvas.drawPath(path, strokePaint)
    }
}