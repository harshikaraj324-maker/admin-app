package com.example.admin.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.admin.R

class GenericAdapter(
    private val list: MutableList<Pair<String, String>>
) : RecyclerView.Adapter<GenericAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvCollection: TextView = v.findViewById(R.id.tvCollection)
        val tvData: TextView = v.findViewById(R.id.tvData)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        return VH(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.item_generic, parent, false)
        )
    }

    override fun onBindViewHolder(h: VH, pos: Int) {
        val item = list[pos]
        h.tvCollection.text = "📂 ${item.first}"
        h.tvData.text = item.second.trim()
    }

    override fun getItemCount(): Int = list.size
}
