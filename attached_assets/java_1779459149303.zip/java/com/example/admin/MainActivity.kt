package com.example.admin

import android.animation.Animator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.admin.activities.LogicActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.messaging.FirebaseMessaging
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "MainActivity"
        private const val TOKENS_NODE = "fcmTokens"
        private const val TOTAL_MS = 3000L
        private const val DISPLAY_TEXT = "--MR ROBOT--"
    }

    private lateinit var tvTitle: TextView
    private lateinit var tvShadow: TextView
    private lateinit var tvPercent: TextView
    private lateinit var tvLoadingText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var ivBg: ImageView

    private var progressAnimator: ValueAnimator? = null
    private val ui = Handler(Looper.getMainLooper())
    private var navigated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvTitle = findViewById(R.id.tvAnimatedText)
        tvShadow = findViewById(R.id.tvAnimatedShadow)
        tvPercent = findViewById(R.id.tvPercent)
        tvLoadingText = findViewById(R.id.tvLoadingText)
        progressBar = findViewById(R.id.pbLoading)
        ivBg = findViewById(R.id.ivStaticBackground)

        loadStaticBackground()

        FirebaseApp.initializeApp(this)
        fetchAndSaveFcmToken()

        startProgressAnimation(TOTAL_MS)
        startTypewriterAnimation(DISPLAY_TEXT, TOTAL_MS)
    }

    private fun loadStaticBackground() {
        Glide.with(this)
            .load(R.drawable.wall)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(ivBg)
    }

    private fun startProgressAnimation(totalMillis: Long) {
        progressBar.max = 100
        progressBar.progress = 0
        tvPercent.text = "0%"

        progressAnimator = ValueAnimator.ofInt(0, 100).apply {
            duration = totalMillis
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { va ->
                val p = va.animatedValue as Int
                progressBar.progress = p
                tvPercent.text = "$p%"
                tvLoadingText.text = when {
                    p < 33 -> "Preparing..."
                    p < 66 -> "Loading..."
                    p < 100 -> "Finalizing..."
                    else -> "Done."
                }
            }
            addListener(object : Animator.AnimatorListener {
                override fun onAnimationStart(animation: Animator) {}
                override fun onAnimationEnd(animation: Animator) { goToLogicActivityOnce() }
                override fun onAnimationCancel(animation: Animator) {}
                override fun onAnimationRepeat(animation: Animator) {}
            })
            start()
        }
    }

    private fun startTypewriterAnimation(text: String, totalMillis: Long) {
        tvTitle.text = ""
        tvShadow.text = ""
        tvTitle.alpha = 1f
        tvShadow.alpha = 0.85f

        val len = text.length
        val step = max(1L, totalMillis / max(1, len))

        for (i in text.indices) {
            ui.postDelayed({
                val current = text.substring(0, i + 1)
                tvTitle.text = current
                tvShadow.text = current

                popOnce(tvTitle, tvShadow)
                if (i == len - 1) {
                    goToLogicActivityOnce()
                }
            }, i * step)
        }
    }

    private fun popOnce(title: TextView, shadow: TextView) {
        val pvhScaleX = PropertyValuesHolder.ofFloat("scaleX", 0.96f, 1.06f, 1.0f)
        val pvhScaleY = PropertyValuesHolder.ofFloat("scaleY", 0.96f, 1.06f, 1.0f)
        val anim = ValueAnimator.ofPropertyValuesHolder(pvhScaleX, pvhScaleY).apply {
            duration = 140L
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { va ->
                val sx = va.getAnimatedValue("scaleX") as Float
                val sy = va.getAnimatedValue("scaleY") as Float
                title.scaleX = sx; title.scaleY = sy
                shadow.scaleX = sx; shadow.scaleY = sy
            }
        }
        anim.start()
    }

    private fun fetchAndSaveFcmToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w(TAG, "⚠ FCM token fetch failed", task.exception)
                return@addOnCompleteListener
            }
            val token = task.result ?: return@addOnCompleteListener
            Log.d(TAG, " FCM Token: $token")

            // local cache
            getSharedPreferences("app_prefs", MODE_PRIVATE)
                .edit().putString("fcm_token", token).apply()

            // upload with dedupe
            val tokensRef = FirebaseDatabase.getInstance().reference.child(TOKENS_NODE)
            tokensRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var exists = false
                    for (child in snapshot.children) {
                        val existing = child.getValue(String::class.java)
                        if (existing == token) { exists = true; break }
                    }
                    if (!exists) {
                        tokensRef.push().setValue(token)
                            .addOnSuccessListener { Log.d(TAG, " Token saved to $TOKENS_NODE") }
                            .addOnFailureListener { e -> Log.e(TAG, " Failed to save token: ${e.message}") }
                    } else {
                        Log.d(TAG, "ℹ Token already exists in $TOKENS_NODE (skip)")
                    }
                }
                override fun onCancelled(error: DatabaseError) {
                    Log.e(TAG, "Failed reading $TOKENS_NODE: ${error.message}")
                }
            })
        }
    }

    private fun goToLogicActivityOnce() {
        if (navigated) return
        navigated = true
        startActivity(Intent(this, LogicActivity::class.java))
        finish()
    }

    override fun onStart() {
        super.onStart()
        Glide.with(this).resumeRequests()
    }

    override fun onStop() {
        Glide.with(this).pauseRequests()
        super.onStop()
    }

    override fun onDestroy() {
        progressAnimator?.cancel()
        progressAnimator = null
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}