package com.example.admin.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import com.example.admin.R
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.database.*
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class DataFetchService : Service() {

    companion object {
        private const val TAG = "DataFetchService"
        private const val NOTIF_ID = 12001
        private const val CHANNEL_ID = "data_fetch_service_channel"
        private const val OVERVIEW_TICK_MS = 5_000L
    }

    // Firebase refs
    private lateinit var dbRefData: DatabaseReference
    private var dbRefStatus: DatabaseReference? = null

    // Listeners
    private var statusChildListener: ChildEventListener? = null
    private var registeredDevicesListener: ValueEventListener? = null

    // In-memory state
    private val registeredDevices = CopyOnWriteArrayList<String>()
    private val statusMap = ConcurrentHashMap<String, Boolean>()

    // Scheduler for overview logging
    private val scheduler = Executors.newScheduledThreadPool(1)
    private var overviewFuture: ScheduledFuture<*>? = null

    private val destroyed = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        setupFirebaseRefs()
        createNotificationChannelIfNeeded()
        startForeground(NOTIF_ID, buildNotification("Monitoring device status"))

        attachRegisteredDevicesListener()
        detectAndAttachStatusNode()

        overviewFuture = scheduler.scheduleAtFixedRate({
            try {
                logOverview()
            } catch (t: Throwable) {
                Log.e(TAG, "Overview tick error", t)
            }
        }, 0, OVERVIEW_TICK_MS, TimeUnit.MILLISECONDS)

        Log.d(TAG, "Service created and foreground started")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        destroyed.set(true)
        removeStatusListener()
        removeRegisteredDevicesListener()
        try { overviewFuture?.cancel(true) } catch (_: Throwable) {}
        try { scheduler.shutdownNow() } catch (_: Throwable) {}
        stopForeground(true)
        Log.d(TAG, "Service destroyed")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------------- Firebase setup ----------------
    private fun setupFirebaseRefs() {
        val db = FirebaseDatabase.getInstance()
        dbRefData = db.getReference("registeredDevices")
    }

    private fun attachRegisteredDevicesListener() {
        removeRegisteredDevicesListener()
        registeredDevicesListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                registeredDevices.clear()
                for (ds in snapshot.children) {
                    val id = ds.key.orEmpty()
                    if (id.isNotBlank()) registeredDevices.add(id)
                }
                Log.d(TAG, "registeredDevices updated size=${registeredDevices.size}")
            }
            override fun onCancelled(error: DatabaseError) {
                Log.w(TAG, "registeredDevices listener cancelled: ${error.message}")
            }
        }
        dbRefData.addValueEventListener(registeredDevicesListener as ValueEventListener)
    }

    private fun removeRegisteredDevicesListener() {
        try {
            registeredDevicesListener?.let { dbRefData.removeEventListener(it) }
            registeredDevicesListener = null
        } catch (e: Exception) {
            Log.w(TAG, "Error removing registeredDevices listener: ${e.message}")
        }
    }

    private fun detectAndAttachStatusNode() {
        val db = FirebaseDatabase.getInstance()
        val candidates = listOf("status", "deviceStatusUpdates")
        fun tryIndex(i: Int) {
            if (i >= candidates.size) {
                dbRefStatus = db.getReference("status")
                initStatusListener()
                return
            }
            val name = candidates[i]
            val ref = db.getReference(name)
            ref.get().addOnSuccessListener { snap ->
                if (snap.exists() && snap.childrenCount > 0) {
                    dbRefStatus = ref
                    for (c in snap.children) {
                        val uid = c.key ?: continue
                        statusMap[uid] = resolveOnlineFlagFromSnapshot(c)
                    }
                    initStatusListener()
                } else {
                    tryIndex(i + 1)
                }
            }.addOnFailureListener {
                tryIndex(i + 1)
            }
        }
        tryIndex(0)
    }

    private fun initStatusListener() {
        val ref = dbRefStatus ?: return
        if (statusChildListener != null) return

        statusChildListener = object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val uid = snapshot.key ?: return
                statusMap[uid] = resolveOnlineFlagFromSnapshot(snapshot)
                Log.d(TAG, "STATUS added: $uid -> ${statusMap[uid]}")
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                val uid = snapshot.key ?: return
                val prev = statusMap[uid]
                statusMap[uid] = resolveOnlineFlagFromSnapshot(snapshot)
                Log.d(TAG, "STATUS changed: $uid : $prev -> ${statusMap[uid]}")
            }

            override fun onChildRemoved(snapshot: DataSnapshot) {
                val uid = snapshot.key ?: return
                statusMap.remove(uid)
                Log.d(TAG, "STATUS removed: $uid")
            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onCancelled(error: DatabaseError) {
                Log.w(TAG, "Status listener cancelled: ${error.message}")
            }
        }
        ref.addChildEventListener(statusChildListener as ChildEventListener)
        Log.d(TAG, "Status listener attached to ${ref.toString()}")
    }

    private fun removeStatusListener() {
        try {
            statusChildListener?.let { dbRefStatus?.removeEventListener(it) }
            statusChildListener = null
        } catch (e: Exception) {
            Log.w(TAG, "Error removing status listener: ${e.message}")
        }
    }

    private fun resolveOnlineFlagFromSnapshot(snap: DataSnapshot): Boolean {
        try {
            val raw = snap.value
            parseFlexibleBoolean(raw)?.let { return it }
        } catch (e: Exception) {
            Log.w(TAG, "resolveOnlineFlagFromSnapshot error: ${e.message}")
        }
        return false
    }

    private fun parseFlexibleBoolean(any: Any?): Boolean? {
        return when (any) {
            null -> null
            is Boolean -> any
            is Number -> any.toInt() != 0
            is String -> {
                when (any.trim().lowercase()) {
                    "true","yes","y","on","online","up","1" -> true
                    "false","no","n","off","offline","down","0","" -> false
                    else -> null
                }
            }
            else -> null
        }
    }

    private fun logOverview() {
        try {
            val online = statusMap.filter { it.value }.keys.toList()
            val offline = statusMap.filter { !it.value }.keys.toList()
            Log.d(TAG, "=== OVERVIEW ===")
            Log.d(TAG, "Registered devices: ${registeredDevices.size}")
            Log.d(TAG, "Online devices(${online.size}): $online")
            Log.d(TAG, "Offline devices(${offline.size}): $offline")
            Log.d(TAG, "================")
        } catch (e: Exception) {
            Log.w(TAG, "logOverview error: ${e.message}")
        }
    }

    private fun createNotificationChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val nm = getSystemService(NotificationManager::class.java)
                val ch = NotificationChannel(CHANNEL_ID, "Data Fetch Service", NotificationManager.IMPORTANCE_LOW)
                ch.description = "Monitors device status"
                nm.createNotificationChannel(ch)
            } catch (e: Exception) {
                Log.w(TAG, "createNotificationChannel error: ${e.message}")
            }
        }
    }
    
    private fun buildNotification(text: String = "Device monitor running"): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Device Monitor")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher)
            .setOngoing(true)
            .build()
    }
}