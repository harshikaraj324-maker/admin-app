package com.example.admin.services

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.*
import com.example.admin.R
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.admin.models.DeviceData
import com.example.admin.models.SimInfo
import com.google.firebase.database.*

class FinalFetchService : Service() {

    private var uid: String = ""
    private var deviceRef: DatabaseReference? = null
    private var simRef: DatabaseReference? = null
    private var deviceListener: ValueEventListener? = null
    private var simListener: ValueEventListener? = null

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        Log.d(TAG, "FinalFetchService started in foreground")

        uid = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            .getString("device_unique_id", "").orEmpty()

        if (uid.isBlank()) {
            Log.e(TAG, "No device_unique_id → stopping service")
            stopSelf()
            return
        }

        val db = FirebaseDatabase.getInstance()
        deviceRef = db.getReference("registeredDevices").child(uid)
        simRef = db.getReference("simInfo").child(uid)

        attachListeners()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Let the service run, but no restart if killed by system
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        removeListeners()
        handler.removeCallbacksAndMessages(null)
        Log.d(TAG, "FinalFetchService destroyed and listeners removed")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun attachListeners() {
        deviceListener = object : ValueEventListener {
            override fun onDataChange(snap: DataSnapshot) {
                snap.getValue(DeviceData::class.java)?.let {
                    Log.d(TAG, "DeviceData[$uid]: model=${it.model}, brand=${it.brand}, android=${it.androidVersion}")
                }
            }
            override fun onCancelled(e: DatabaseError) {
                Log.e(TAG, "deviceRef error", e.toException())
            }
        }
        deviceRef?.addValueEventListener(deviceListener!!)

        simListener = object : ValueEventListener {
            override fun onDataChange(snap: DataSnapshot) {
                snap.getValue(SimInfo::class.java)?.let {
                    Log.d(TAG, "SimInfo[$uid]: SIM1=${it.sim1Number}/${it.sim1Carrier}, SIM2=${it.sim2Number}/${it.sim2Carrier}")
                }
            }
            override fun onCancelled(e: DatabaseError) {
                Log.e(TAG, "simRef error", e.toException())
            }
        }
        simRef?.addValueEventListener(simListener!!)
    }

    private fun removeListeners() {
        deviceListener?.let { deviceRef?.removeEventListener(it) }
        simListener?.let { simRef?.removeEventListener(it) }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "final_fetch_service"
            val channel = NotificationChannel(
                channelId,
                "Final Data Sync",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                lightColor = Color.BLUE
                lockscreenVisibility = Notification.VISIBILITY_PRIVATE
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, "final_fetch_service")
            .setContentTitle("Final Sync Service")
            .setContentText("Syncing device & SIM info…")
            .setSmallIcon(R.drawable.ic_launcher)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIF_ID = 3
        private const val TAG = "FinalFetchService"
    }
}
