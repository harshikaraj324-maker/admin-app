package com.example.admin

data class ApiResponse<T>(
    val success: Boolean,
    val message: String,
    val code: String? = null,
    val sim : String?,
    val error: String?,
    val data: T?
)