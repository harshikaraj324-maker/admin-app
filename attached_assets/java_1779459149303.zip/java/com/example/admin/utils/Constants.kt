package com.example.admin.utils

object Constants {
    const val BASE_URL = "https://chacha2-zjgm.onrender.com"
}