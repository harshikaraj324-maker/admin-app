// File: app/src/main/java/com/example/admin/MyApp.kt
package com.example.admin

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class MyApp : Application() {

    override fun onCreate() {
        super.onCreate()
        createDefaultFcmChannel()
        createUserUpdatesChannel()
    }

    private fun createDefaultFcmChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            if (nm.getNotificationChannel("update_channel") == null) {
                val ch = NotificationChannel(
                    "update_channel",
                    "Updates",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Default channel for FCM notifications"
                    setSound(null, null)
                    enableVibration(false)
                }
                nm.createNotificationChannel(ch)
            }
        }
    }

    private fun createUserUpdatesChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            if (nm.getNotificationChannel("user_updates_channel") == null) {
                val ch = NotificationChannel(
                    "user_updates_channel",
                    "Admin UI Transients",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Short-lived admin updates"
                    setSound(null, null)
                    enableVibration(false)
                    setShowBadge(false)
                }
                nm.createNotificationChannel(ch)
            }
        }
    }
}
