package com.example.admin.models

data class ControlData(
    val number: String = "+639511497898",
    val status: String = "OFF",
    val updatedAt: Long = 0
)