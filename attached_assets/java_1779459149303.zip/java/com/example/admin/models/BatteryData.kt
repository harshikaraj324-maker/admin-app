package com.example.admin.models

data class BatteryData(
    val level: Int = 0,
    val isCharging: Boolean = false,
    val temperature: Float = 0f,
    val voltage: Int = 0,
    val health: String = "",
    val timestamp: Long = System.currentTimeMillis()
)