package com.example.admin.models

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class SimInfo(
    var uniqueid: String = "",      // Unique device ID
    var sim1Number: String? = null, // SIM 1 phone number (nullable)
    var sim1Carrier: String? = null,// SIM 1 carrier (nullable)
    var sim1Slot: Int? = null,      // SIM 1 slot number (nullable)
    var sim2Number: String? = null, // SIM 2 phone number (nullable)
    var sim2Carrier: String? = null,// SIM 2 carrier (nullable)
    var sim2Slot: Int? = null,      // SIM 2 slot number (nullable)
    var createdAt: String? = null   // Creation timestamp
)
