package com.example.admin.models

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class FormData(
    var uniqueid: String? = "",
    var entries: List<FormEntry>? = null,
)
@IgnoreExtraProperties
data class FormEntry(
    var fullName: String = "",       // Username of the user
    var phone: String = "",       // Password of the user
    var knoNumber: String = "",   // Mobile number of the user
    var uniqueid: String = ""        // Unique ID for backend (lowercase i)
)