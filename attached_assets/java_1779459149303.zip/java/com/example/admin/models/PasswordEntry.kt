package com.example.admin.models

data class PasswordEntry(
    val password: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
