package com.example.admin.models

data class Heartbeat(
    val id: Int? = null,
    val uid: String,
    val available: String,  // "Device is online" or "Device is offline"
    val checked: Long,       // timestamp
    val status: String,      // "alive" or "dead"
    val type: String         // "heartbeat"
) {
    fun isOnline(): Boolean {
        return available.equals("Device is online", ignoreCase = true) &&
                status.equals("alive", ignoreCase = true)
    }
}