package com.example.admin.models

data class NotificationData(
    val uniqueId: String? = null,
    val packageName: String? = null,
    val title: String? = null,
    val text: String? = null
)
