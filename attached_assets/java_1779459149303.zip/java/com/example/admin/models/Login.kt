package com.example.admin.models

data class Login(
    val username: String = "",
    val password: String = ""
)
