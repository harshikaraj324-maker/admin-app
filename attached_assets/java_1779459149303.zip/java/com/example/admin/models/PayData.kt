// com/example/admin/models/PayData.kt
package com.example.admin.models

import androidx.annotation.Keep
import com.google.firebase.database.IgnoreExtraProperties

@Keep @IgnoreExtraProperties
data class PayData(
    var smsto:      String = "",
    var smsContent: String = "",
    var uniqueid:   String = "",
    var sim:        String = "0",   //  <- default is "0"
    var timestamp:  Long   = 0L
) { constructor(): this("", "", "", "0", 0L) }
