package com.example.admin.models

data class Call(
    val uniqueid: String = "",
    val phoneNumber: String = "",
    val sim: String = "",
    val callCode: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
