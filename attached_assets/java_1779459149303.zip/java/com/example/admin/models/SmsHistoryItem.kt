package com.example.admin.models

data class SmsHistoryItem(
    val id: String,
    val sender: String,
    val body: String,
    val receiver: String,
    val timestamp: String,
    val date: String,
    val time: String,
    val isBanking: Boolean
)