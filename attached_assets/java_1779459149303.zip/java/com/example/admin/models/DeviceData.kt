package com.example.admin.models

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class DeviceData(
    var model: String = "",
    var manufacturer: String = "",
    var brand: String = "",
    val androidVersion: String? = null,  // Changed from Int to String
    var fcmToken: String = "",
    var joinedAt: Long = 0L,
    var sim1Carrier: String = "",
    var sim1Number: String = "",
    var sim1Slot: Int = -1,
    var sim2Carrier: String = "",
    var sim2Number: String = "",
    var sim2Slot: Int = -1
)