package com.example.admin.models

data class Status(
    val online: Boolean? = null,
    val timestamp: String? = null,
    val uniqueid: String? = null
)
