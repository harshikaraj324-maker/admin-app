package com.example.admin.models

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class SmsData(
    val body: String? = null,
    val receiverNumber: String? = null,
    val senderNumber: String? = null,
    val timestamp: Any? = null,
    val title: String? = null
) {
    constructor() : this(null, null, null, null, null)
}