package com.example.admin.models

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class DeviceStatusUpdate(
    var uniqueid: String? = "",
    var batteryLevel: Int = 0,
    var isCharging: Boolean = false,
    var connectivity: String = "",
    val timestamp: Double? = null
)
